from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, round, desc
import time

# Initializing the Spark Session
spark = SparkSession.builder.appName("IMDb Analysis").getOrCreate()

# Loading in the two datasets
action_df = spark.read.csv(r"C:\Users\ykevi\OneDrive\Documents\Computer Science\Year 3\Semester 2\Programming for Big Data\Big_Data_Files\horror.csv", header=True, inferSchema=True)
horror_df = spark.read.csv(r"C:\Users\ykevi\OneDrive\Documents\Computer Science\Year 3\Semester 2\Programming for Big Data\Big_Data_Files\horror.csv", header=True, inferSchema=True)

# Start timer
start_time = time.time()

# Filter out movies with missing or invalid ratings and getting the count of them
action_filtered = action_df.filter(col("rating") > 0)
horror_filtered = horror_df.filter(col("rating") > 0)
action_count = action_filtered.count()
horror_count = horror_filtered.count()
print("\n\nAction Movies:", action_count, "\nHorror Movies:", horror_count)

# End timer
end_time = time.time()
exec_time = end_time - start_time
print("Execution Time:", exec_time, "seconds\n\n")

# Start timer
start_time = time.time()

action_avg_rating = action_filtered.select(round(avg("rating"), 2)).collect()[0][0]
horror_avg_rating = horror_filtered.select(round(avg("rating"), 2)).collect()[0][0]
print("\n\nAverage Action Movie Rating:", action_avg_rating)
print("Average Horror Movie Rating:", horror_avg_rating)

# End timer
end_time = time.time()
exec_time = end_time - start_time
print("Execution Time:", exec_time, "seconds\n\n")

# Start timer
start_time = time.time()

# Top 5 highest-rated movies
action_top = action_filtered.orderBy(desc("rating")).select("movie_name", "rating").limit(5)
horror_top = horror_filtered.orderBy(desc("rating")).select("movie_name", "rating").limit(5)

# Top 5 lowest-rated movies
action_low = action_filtered.orderBy("rating").select("movie_name", "rating").limit(5)
horror_low = horror_filtered.orderBy("rating").select("movie_name", "rating").limit(5)

action_top.show()
action_low.show()
horror_top.show()
horror_low.show()

# End timer
end_time = time.time()
exec_time = end_time - start_time
print("\n\nExecution Time:", exec_time, "seconds\n\n")


